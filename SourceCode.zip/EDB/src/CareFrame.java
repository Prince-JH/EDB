
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

public class CareFrame extends JFrame {
	int num = 0;
	Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    private JTextArea textArea;
	private JTextArea textArea_1;
	private JTextArea textArea_2;
	private JTextArea textArea_3;
	private JTextArea textArea_4;
	private JTextArea textArea_5;
	private JTextArea textArea_6;
	private JTextArea textArea_7;
    int i = 0;
	private JPanel contentPane;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CareFrame frame = new CareFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public CareFrame() {
		setPreferredSize(new Dimension(1050, 700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 832, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("\uC548\uC2EC \uB3CC\uBD04 \uC11C\uBE44\uC2A4");
		lblNewLabel.setPreferredSize(new Dimension(120, 50));
		lblNewLabel.setBorder(new BevelBorder(BevelBorder.RAISED));
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		GridLayout gl2 = new GridLayout(8, 1);
		panel_1.setLayout(gl2);
		contentPane.add(panel_1, BorderLayout.CENTER);
		
		textArea = new JTextArea();
		textArea.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea);
		
		textArea_1 = new JTextArea();
		textArea_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_1);
		
		textArea_2 = new JTextArea();
		textArea_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_2);
		
		textArea_3 = new JTextArea();
		textArea_3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_3);
		
		textArea_4 = new JTextArea();
		textArea_4.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_4);
		
		textArea_5 = new JTextArea();
		textArea_5.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_5);
		
		textArea_6 = new JTextArea();
		textArea_6.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_6);
		
		textArea_7 = new JTextArea();
		textArea_7.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_7);

		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.SOUTH);
		
		JButton button1_3_1 = new JButton("���ư���");
		button1_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
			}
		});
		panel_2.add(button1_3_1);
		
		JPanel panel_3 = new JPanel();
		GridLayout gl3 = new GridLayout(3, 1);
		panel_3.setLayout(gl3);
		contentPane.add(panel_3, BorderLayout.EAST);
		
		Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        ArrayList<String> service = new ArrayList<>();
        ArrayList<String> facility = new ArrayList<>();
        ArrayList<String> program = new ArrayList<>();
        ArrayList<String> target = new ArrayList<>();
        ArrayList<String> how = new ArrayList<>();
        ArrayList<String> fee = new ArrayList<>();
        ArrayList<String> operation = new ArrayList<>();
        ArrayList<String> limit = new ArrayList<>();
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost/edb_prj";
            conn = DriverManager.getConnection(url, "root", "autoset");
            stmt = conn.createStatement();
            String sql = "SELECT ���α׷���, �ü���, ���α׷�����, �������, ��û���, �̿��, ��Ⱓ, �̿�Ƚ������ FROM �������� WHERE ����з� = '�Ƚɵ�������'";
            rs = stmt.executeQuery(sql);
            while(rs.next()){
            	service.add(rs.getString(1));
            	facility.add(rs.getString(2));
            	program.add(rs.getString(3));
            	target.add(rs.getString(4));
            	how.add(rs.getString(5));
            	fee.add(rs.getString(6));
            	operation.add(rs.getString(7));
            	limit.add(rs.getString(8));      	
            }
        }
        catch(ClassNotFoundException ee){
            System.out.println("����̹� �ε� ����");
        }
        catch(SQLException ee){
            System.out.println("����: " + ee);
        }
        finally{
            try{
                if( conn != null && !conn.isClosed()){
                    conn.close();
                }
            }
            catch( SQLException ee){
                ee.printStackTrace();
            }
        }
        
		JButton btnNewButton = new JButton("����");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i != service.size() - 1)
					i++;
				else
					i = 0;
				textArea.setText("���� �� : " + service.get(i));
	            textArea_1.setText("�ü� �� : " + facility.get(i));
	            textArea_2.setText("���α׷� ����  : " + program.get(i));
	            textArea_3.setText("������� : " + target.get(i));
	            textArea_4.setText("��û��� : " + how.get(i));
	            textArea_5.setText("�̿� ��� : " + fee.get(i));
	            textArea_6.setText("� �Ⱓ: " + operation.get(i));
	            textArea_7.setText("�̿� Ƚ�� ����: " + limit.get(i));
				
			}
		});
		panel_3.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i == 0)
					i = service.size() - 1;
				else
					i--;
				textArea.setText("���� �� : " + service.get(i));
	            textArea_1.setText("�ü� �� : " + facility.get(i));
	            textArea_2.setText("���α׷� ����  : " + program.get(i));
	            textArea_3.setText("������� : " + target.get(i));
	            textArea_4.setText("��û��� : " + how.get(i));
	            textArea_5.setText("�̿� ��� : " + fee.get(i));
	            textArea_6.setText("� �Ⱓ: " + operation.get(i));
	            textArea_7.setText("�̿� Ƚ�� ����: " + limit.get(i));
				
			}
		});
		panel_3.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("�ü� ��ġ ����");
		panel_3.add(btnNewButton_1_1);
	}

}
