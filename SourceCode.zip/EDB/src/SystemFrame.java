
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

public class SystemFrame extends JFrame {
	int num = 0;
	Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    private JTextArea textArea;
	private JTextArea textArea_1;
	private JTextArea textArea_2;
	private JTextArea textArea_3;
	private JTextArea textArea_4;
    int i = 0;
	private JPanel contentPane;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SystemFrame frame = new SystemFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public SystemFrame() {
		setPreferredSize(new Dimension(1050, 700));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 832, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("\uBCF5\uC9C0 \uC81C\uB3C4");
		lblNewLabel.setPreferredSize(new Dimension(100, 50));
		lblNewLabel.setBorder(new BevelBorder(BevelBorder.RAISED));
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		GridLayout gl2 = new GridLayout(5, 1);
		panel_1.setLayout(gl2);
		contentPane.add(panel_1, BorderLayout.CENTER);
		
		textArea = new JTextArea();
		textArea.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea);
		
		textArea_1 = new JTextArea();
		textArea_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_1);
		
		textArea_2 = new JTextArea();
		textArea_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_2);
		
		textArea_3 = new JTextArea();
		textArea_3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_3);
		
		textArea_4 = new JTextArea();
		textArea_4.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.add(textArea_4);

		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.SOUTH);
		
		JButton button1_3_1 = new JButton("���ư���");
		button1_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
			}
		});
		panel_2.add(button1_3_1);
		
		JPanel panel_3 = new JPanel();
		GridLayout gl3 = new GridLayout(3, 1);
		panel_3.setLayout(gl3);
		contentPane.add(panel_3, BorderLayout.EAST);
		
		Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        ArrayList<String> name = new ArrayList<>();
        ArrayList<String> content = new ArrayList<>();
        ArrayList<String> target = new ArrayList<>();
        ArrayList<String> how = new ArrayList<>();
        ArrayList<String> ask = new ArrayList<>();
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost/edb_prj";
            conn = DriverManager.getConnection(url, "root", "autoset");
            stmt = conn.createStatement();
            String sql = "SELECT ������, ����, ���, ���, ���� FROM ����";
            rs = stmt.executeQuery(sql);
            while(rs.next()){
            	name.add(rs.getString(1));
            	content.add(rs.getString(2));
            	target.add(rs.getString(3));
            	how.add(rs.getString(4));
            	ask.add(rs.getString(5));
            }
        }
        catch(ClassNotFoundException ee){
            System.out.println("����̹� �ε� ����");
        }
        catch(SQLException ee){
            System.out.println("����: " + ee);
        }
        finally{
            try{
                if( conn != null && !conn.isClosed()){
                    conn.close();
                }
            }
            catch( SQLException ee){
                ee.printStackTrace();
            }
        }
        
		JButton btnNewButton = new JButton("����");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i != name.size() - 1)
					i++;
				else
					i = 0;
				textArea.setText("���� ��: " + name.get(i));
	            textArea_1.setText("����: " + content.get(i));
	            textArea_2.setText("��� : " + target.get(i));
	            textArea_3.setText("���: " + how.get(i));
	            textArea_4.setText("����: " + ask.get(i));
			}
		});
		panel_3.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i == 0)
					i = name.size() - 1;
				else
					i--;
				textArea.setText("���� ��: " + name.get(i));
	            textArea_1.setText("����: " + content.get(i));
	            textArea_2.setText("��� : " + target.get(i));
	            textArea_3.setText("���: " + how.get(i));
	            textArea_4.setText("����: " + ask.get(i));
				
			}
		});
		panel_3.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("�ü� ��ġ ����");
		panel_3.add(btnNewButton_1_1);
	}

}
