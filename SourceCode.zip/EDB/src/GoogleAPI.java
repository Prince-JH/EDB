import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

public class GoogleAPI {

	public void downloadMap(String location) {
		try {
			String imageURL = "";
				
			URL url = new URL(imageURL);
			InputStream is = url.openStream();
			OutputStream os = new FileOutputStream(location);
			byte[] b = new byte[2048];
 			}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
