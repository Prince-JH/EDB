import java.sql.*;
import java.util.ArrayList;

public class DBManager {
    public static void main(String[] args) {
    	
        
    }
}